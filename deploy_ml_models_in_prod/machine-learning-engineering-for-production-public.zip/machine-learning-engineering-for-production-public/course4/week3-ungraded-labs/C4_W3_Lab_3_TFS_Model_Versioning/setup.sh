wget -q -P ./models/animals/1/ https://storage.googleapis.com/mlep-public/course_1/week2/model-balanced/saved_model.pb
wget -q -P ./models/animals/1/variables/ https://storage.googleapis.com/mlep-public/course_1/week2/model-balanced/variables/variables.data-00000-of-00001
wget -q -P ./models/animals/1/variables/ https://storage.googleapis.com/mlep-public/course_1/week2/model-balanced/variables/variables.index

wget -q -P ./models/animals/2/ https://storage.googleapis.com/mlep-public/course_1/week2/model-imbalanced/saved_model.pb
wget -q -P ./models/animals/2/variables/ https://storage.googleapis.com/mlep-public/course_1/week2/model-imbalanced/variables/variables.data-00000-of-00001
wget -q -P ./models/animals/2/variables/ https://storage.googleapis.com/mlep-public/course_1/week2/model-imbalanced/variables/variables.index

wget -q -P ./models/animals/3/ https://storage.googleapis.com/mlep-public/course_1/week2/model-augmented/saved_model.pb
wget -q -P ./models/animals/3/variables/ https://storage.googleapis.com/mlep-public/course_1/week2/model-augmented/variables/variables.data-00000-of-00001
wget -q -P ./models/animals/3/variables/ https://storage.googleapis.com/mlep-public/course_1/week2/model-augmented/variables/variables.index